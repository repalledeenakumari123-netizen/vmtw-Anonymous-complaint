import os
import re
import random
import string
import uuid
from datetime import datetime, timedelta
from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify)
from werkzeug.utils import secure_filename
from database import init_db, get_db

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'vmtw-secret-key-2024-change-in-prod')
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

DEPARTMENTS = ['CSE', 'CSE-AI', 'CSE-DS', 'IT', 'ECE', 'EEE', 'MBA', 'BBA']

# Valid statuses (updated as requested)
VALID_STATUSES = ['Received', 'Under Review', 'Action Taken']

# Roll number: year prefix (22-25) + UP1A05 + 2-char suffix (01-99 or A0-Z9)
ROLL_PATTERN = re.compile(r'^(22|23|24|25)UP1A05(\d{2}|[A-Z]\d)$')

# ─── Helpers ──────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_roll_number(roll):
    return bool(ROLL_PATTERN.match(roll.upper().strip()))

def generate_otp():
    return str(random.randint(100000, 999999))

def generate_complaint_id():
    """Format: CMP-XXXXXX  (6 random digits for easy reading)"""
    digits = ''.join(random.choices(string.digits, k=6))
    return f'CMP-{digits}'

def get_year_from_roll(roll):
    prefix = roll[:2]
    return {'25': '1st Year', '24': '2nd Year', '23': '3rd Year', '22': '4th Year'}.get(prefix, 'Unknown')

# ─── PUBLIC ROUTES ────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        roll = request.form.get('roll_number', '').strip().upper()
        if not roll:
            flash('Please enter your Roll Number.', 'danger')
            return render_template('verify.html')
        if not validate_roll_number(roll):
            flash('Invalid Roll Number format. Please check and try again.', 'danger')
            return render_template('verify.html', roll=roll)

        otp = generate_otp()
        # Store OTP and roll temporarily for the verification step only
        session['otp']          = otp
        session['otp_roll']     = roll          # discarded after OTP is verified
        session['otp_expires']  = (datetime.now() + timedelta(minutes=10)).isoformat()
        session['otp_attempts'] = 0

        return render_template('otp.html', roll=roll, otp_demo=otp,
                               year=get_year_from_roll(roll))
    return render_template('verify.html')


@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    entered_otp = request.form.get('otp', '').strip()
    roll        = session.get('otp_roll')
    stored_otp  = session.get('otp')
    expires_str = session.get('otp_expires')
    attempts    = session.get('otp_attempts', 0)

    if not roll or not stored_otp:
        flash('Session expired. Please start again.', 'danger')
        return redirect(url_for('verify'))

    if expires_str and datetime.now() > datetime.fromisoformat(expires_str):
        session.pop('otp', None)
        flash('OTP expired. Please request a new one.', 'danger')
        return redirect(url_for('verify'))

    if attempts >= 5:
        session.clear()
        flash('Too many failed attempts. Please start over.', 'danger')
        return redirect(url_for('verify'))

    if entered_otp == stored_otp:
        # ── DISCARD all identity data immediately ──────────────────────────
        session.pop('otp',          None)
        session.pop('otp_roll',     None)   # roll number gone — never stored in DB
        session.pop('otp_expires',  None)
        session.pop('otp_attempts', None)

        # Only signal: "this session is verified" and "no complaint filed yet"
        session['verified']           = True
        session['complaint_submitted'] = False   # one-complaint-per-session guard
        session['verified_at']        = datetime.now().isoformat()

        flash('Verification successful! You may now submit your complaint.', 'success')
        return redirect(url_for('submit_complaint'))

    else:
        session['otp_attempts'] = attempts + 1
        remaining = 5 - (attempts + 1)
        flash(f'Incorrect OTP. {remaining} attempt(s) remaining.', 'danger')
        return render_template('otp.html', roll=roll, otp_demo=stored_otp,
                               year=get_year_from_roll(roll))


@app.route('/resend-otp', methods=['POST'])
def resend_otp():
    if not session.get('otp_roll'):
        return jsonify({'error': 'No active session'}), 400
    otp = generate_otp()
    session['otp']          = otp
    session['otp_expires']  = (datetime.now() + timedelta(minutes=10)).isoformat()
    session['otp_attempts'] = 0
    return jsonify({'success': True, 'otp': otp})


@app.route('/complaint', methods=['GET', 'POST'])
def submit_complaint():
    # Must be OTP-verified
    if not session.get('verified'):
        flash('Please verify your Roll Number first.', 'warning')
        return redirect(url_for('verify'))

    # One complaint per session
    if session.get('complaint_submitted'):
        flash('You have already submitted a complaint in this session. '
              'Please use your Complaint ID to track it.', 'warning')
        cid = session.get('last_complaint_id')
        if cid:
            return redirect(url_for('confirmation', complaint_id=cid))
        return redirect(url_for('track'))

    if request.method == 'POST':
        department  = request.form.get('department',  '').strip()
        title       = request.form.get('title',       '').strip()
        description = request.form.get('description', '').strip()

        errors = []
        if department not in DEPARTMENTS:
            errors.append('Please select a valid department.')
        if not title or len(title) < 5:
            errors.append('Complaint title must be at least 5 characters.')
        if not description or len(description) < 20:
            errors.append('Complaint description must be at least 20 characters.')

        image_path = None
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{uuid.uuid4()}_{file.filename}")
                file.save(os.path.join(UPLOAD_FOLDER, filename))
                image_path = f'uploads/{filename}'
            elif file and file.filename:
                errors.append('Invalid file type. Allowed: PNG, JPG, JPEG, GIF, WEBP.')

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('complaint.html', departments=DEPARTMENTS)

        # ── Save complaint — NO identity columns ───────────────────────────
        complaint_id = generate_complaint_id()
        db = get_db()
        db.execute(
            '''INSERT INTO complaints
               (complaint_id, department, title, description, image_path)
               VALUES (?, ?, ?, ?, ?)''',
            (complaint_id, department, title, description, image_path)
        )
        db.commit()
        db.close()

        # Mark session: complaint filed, store ID for confirmation redirect only
        session['complaint_submitted'] = True
        session['last_complaint_id']   = complaint_id

        return redirect(url_for('confirmation', complaint_id=complaint_id))

    return render_template('complaint.html', departments=DEPARTMENTS)


@app.route('/confirmation/<complaint_id>')
def confirmation(complaint_id):
    db = get_db()
    complaint = db.execute(
        "SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,)
    ).fetchone()
    db.close()
    if not complaint:
        flash('Complaint not found.', 'danger')
        return redirect(url_for('index'))
    return render_template('confirmation.html', complaint=complaint)


@app.route('/track', methods=['GET', 'POST'])
def track():
    complaint = None
    if request.method == 'POST':
        cid = request.form.get('complaint_id', '').strip().upper()
        db = get_db()
        complaint = db.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?", (cid,)
        ).fetchone()
        db.close()
        if not complaint:
            flash('No complaint found with that ID. Please check and try again.', 'danger')
    return render_template('track.html', complaint=complaint)


# ─── ADMIN ROUTES ─────────────────────────────────────────────────────────────

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_dashboard'))
    if request.method == 'POST':
        admin_id = request.form.get('admin_id', '').strip()
        password = request.form.get('password', '').strip()
        db    = get_db()
        admin = db.execute(
            "SELECT * FROM admin WHERE admin_id = ? AND password = ?",
            (admin_id, password)
        ).fetchone()
        db.close()
        if admin:
            session['admin_logged_in'] = True
            session['admin_role']      = admin['role']
            session['admin_id']        = admin['admin_id']
            return redirect(url_for('admin_dashboard'))
        flash('Invalid credentials. Please try again.', 'danger')
    return render_template('admin_login.html')


@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    dept_filter   = request.args.get('department', '')
    status_filter = request.args.get('status', '')

    db     = get_db()
    query  = "SELECT * FROM complaints WHERE 1=1"
    params = []

    if dept_filter and dept_filter in DEPARTMENTS:
        query += " AND department = ?"
        params.append(dept_filter)
    if status_filter in VALID_STATUSES:
        query += " AND status = ?"
        params.append(status_filter)

    query += " ORDER BY created_at DESC"
    complaints = db.execute(query, params).fetchall()

    stats = {
        'total':        db.execute("SELECT COUNT(*) FROM complaints").fetchone()[0],
        'received':     db.execute("SELECT COUNT(*) FROM complaints WHERE status='Received'").fetchone()[0],
        'under_review': db.execute("SELECT COUNT(*) FROM complaints WHERE status='Under Review'").fetchone()[0],
        'action_taken': db.execute("SELECT COUNT(*) FROM complaints WHERE status='Action Taken'").fetchone()[0],
    }
    db.close()

    return render_template('admin_dashboard.html',
                           complaints=complaints,
                           departments=DEPARTMENTS,
                           valid_statuses=VALID_STATUSES,
                           stats=stats,
                           dept_filter=dept_filter,
                           status_filter=status_filter)


@app.route('/admin/update-status', methods=['POST'])
def update_status():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
    cid    = request.form.get('complaint_id')
    status = request.form.get('status')
    if status not in VALID_STATUSES:
        return jsonify({'error': 'Invalid status'}), 400
    db = get_db()
    db.execute(
        "UPDATE complaints SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE complaint_id = ?",
        (status, cid)
    )
    db.commit()
    db.close()
    return jsonify({'success': True})


@app.route('/admin/delete/<complaint_id>', methods=['POST'])
def delete_complaint(complaint_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    db        = get_db()
    complaint = db.execute(
        "SELECT image_path FROM complaints WHERE complaint_id = ?", (complaint_id,)
    ).fetchone()
    if complaint and complaint['image_path']:
        img_file = os.path.join(os.path.dirname(__file__), 'static', complaint['image_path'])
        if os.path.exists(img_file):
            os.remove(img_file)
    db.execute("DELETE FROM complaints WHERE complaint_id = ?", (complaint_id,))
    db.commit()
    db.close()
    flash('Complaint deleted successfully.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/view/<complaint_id>')
def view_complaint(complaint_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    db        = get_db()
    complaint = db.execute(
        "SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,)
    ).fetchone()
    db.close()
    if not complaint:
        flash('Complaint not found.', 'danger')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_view.html', complaint=complaint,
                           valid_statuses=VALID_STATUSES)


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    session.pop('admin_role',      None)
    session.pop('admin_id',        None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('admin_login'))


# ─── Bootstrap ────────────────────────────────────────────────────────────────

init_db()   # runs for both `python app.py` and gunicorn

if __name__ == '__main__':
    app.run(debug=True)
