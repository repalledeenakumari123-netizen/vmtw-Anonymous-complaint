// VMTW Complaint Portal — Main JS

// Auto-dismiss flash messages
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => {
    const bsAlert = bootstrap.Alert.getOrCreateInstance(el);
    if (bsAlert) bsAlert.close();
  }, 5000);
});

// Active nav link
const currentPath = window.location.pathname;
document.querySelectorAll('.nav-link').forEach(link => {
  if (link.getAttribute('href') === currentPath) link.classList.add('active');
});

// Smooth scroll to top on page load
window.scrollTo({ top: 0, behavior: 'smooth' });
