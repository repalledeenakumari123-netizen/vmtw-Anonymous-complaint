import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'instance', 'vmtw.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    c = conn.cursor()

    # ── Complaints: ZERO identity columns ──────────────────────────────────
    # No roll_number. No student_name. No IP address. Pure content only.
    c.execute('''
        CREATE TABLE IF NOT EXISTS complaints (
            id           INTEGER  PRIMARY KEY AUTOINCREMENT,
            complaint_id TEXT     UNIQUE NOT NULL,
            department   TEXT     NOT NULL,
            title        TEXT     NOT NULL,
            description  TEXT     NOT NULL,
            image_path   TEXT,
            status       TEXT     DEFAULT 'Received',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # ── Admin accounts ─────────────────────────────────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS admin (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id TEXT    UNIQUE NOT NULL,
            password TEXT    NOT NULL,
            role     TEXT    NOT NULL
        )
    ''')

    # Seed default admin
    c.execute("SELECT id FROM admin WHERE admin_id = 'principal_vmtw'")
    if not c.fetchone():
        c.execute(
            "INSERT INTO admin (admin_id, password, role) VALUES (?, ?, ?)",
            ('principal_vmtw', 'admin@123', 'Principal')
        )

    conn.commit()
    conn.close()
